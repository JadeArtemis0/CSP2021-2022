#   Add your code here and add comments to your code 
#   to describe what each section of code is doing
import turtle as trtl
from turtle import *
# create turtle object
painter = trtl.Turtle()

#Asks what color sould the line of the circle be
a = input ("What coulor would you like the circle to be?")
b = input ("What coulor would you like the circle to be?")
c = input ("What coulor would you like the circle to be?")
d = input ("What coulor would you like the circle to be?")
e = input ("What coulor would you like the circle to be?")
f = input ("What coulor would you like the circle to be?")




painter.pensize(5)


# then draw a polygon + fill the circle 

fav_color = a
painter.fillcolor(fav_color)
painter.begin_fill()
painter.circle(20, 180, 3)
painter.circle(20, 180, 3)
painter.end_fill()
fav_color = b
painter.fillcolor(fav_color)
painter.begin_fill()
painter.circle(20, 180, 3)
painter.circle(20, 180, 3)
painter.end_fill()

fav_color = c
painter.fillcolor(fav_color)
painter.begin_fill()
painter.circle(20, 180, 3)
painter.circle(20, 180, 3)
painter.end_fill()

fav_color = d
painter.fillcolor(fav_color)
painter.begin_fill()
painter.circle(20, 180, 3)
painter.circle(20, 180, 3)
painter.end_fill()

fav_color = e
painter.fillcolor(fav_color)
painter.begin_fill()
painter.circle(20, 180, 3)
painter.circle(20, 180, 3)
painter.end_fill()

fav_color = f
painter.fillcolor(fav_color)
painter.begin_fill()
painter.circle(20, 180, 3)
painter.circle(20, 180, 3)
painter.end_fill()

wn = trtl.Screen()
wn.mainloop()